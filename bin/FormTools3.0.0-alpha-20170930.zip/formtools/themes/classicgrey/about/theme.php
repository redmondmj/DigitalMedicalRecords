<?php

/**
 * Form Tools Theme File
 * ---------------------
 */

$theme_name = "Classic Grey";
$theme_author = "Ben Keen";
$theme_author_email = "ben.keen@gmail.com";
$theme_link = "http://themes.formtools.org";
$theme_description = "A remodelling of the old grey-styled Form Tools 1.x theme.";
$theme_version = "2.0.0";
$theme_uses_swatches = "no";
