<?php
session_write_close();
header("location: ../../");
?>