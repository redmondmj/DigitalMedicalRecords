<?php

require_once(__DIR__ . "/code/Files.class.php");
require_once(__DIR__ . "/code/General.class.php");
require_once(__DIR__ . "/code/Generation.class.php");
require_once(__DIR__ . "/code/Hooks.class.php");
require_once(__DIR__ . "/code/Module.class.php");
require_once(__DIR__ . "/code/Orphans.class.php");
require_once(__DIR__ . "/code/Tables.class.php");
