<?php

require_once("../../global/library.php");

$module = FormTools\Modules::initModulePage("admin");

$module->displayPage("templates/help.tpl", array());
