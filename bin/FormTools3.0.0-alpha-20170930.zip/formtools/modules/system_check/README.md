## module-system_check

This module replaces the older Database Integrity module. It offers a few simple, quick tests to run on your Form Tools 
installation: kind of like taking your car to get it serviced.

### Documentation

[https://docs.formtools.org/modules/system_check/](https://docs.formtools.org/modules/system_check/)

### Form Tools Extensions

For a full list of Form Tools modules, see: 
[https://modules.formtools.org/](https://modules.formtools.org/)
