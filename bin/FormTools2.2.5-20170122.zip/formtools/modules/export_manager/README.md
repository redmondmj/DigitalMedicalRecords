module_export_manager
=====================

The Export Manager module.
