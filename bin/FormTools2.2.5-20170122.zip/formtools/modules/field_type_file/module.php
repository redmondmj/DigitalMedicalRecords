<?php

/*
 * Module file: File Upload
 */

$MODULE["author"]          = "Ben Keen";
$MODULE["author_email"]    = "ben.keen@gmail.com";
$MODULE["author_link"]     = "http://www.formtools.org";
$MODULE["version"]         = "1.1.0";
$MODULE["date"]            = "2012-05-16";
$MODULE["origin_language"] = "en_us";

$MODULE["nav"] = array(
  "module_name" => array('{$module_dir}/index.php', false)
    );