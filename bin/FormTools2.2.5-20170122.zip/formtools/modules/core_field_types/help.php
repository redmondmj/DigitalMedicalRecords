<?php

require("../../global/library.php");
$folder = dirname(__FILE__);
ft_init_module_page();

ft_display_module_page("templates/help.tpl");