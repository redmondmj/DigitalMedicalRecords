<?php

require_once(dirname(__FILE__) . "/global/code/field_types.php");
require_once(dirname(__FILE__) . "/global/code/general.php");
require_once(dirname(__FILE__) . "/global/code/module.php");
