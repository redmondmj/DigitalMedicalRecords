<?php

require_once("../../global/library.php");
ft_init_module_page();

$page_vars = array();
ft_display_module_page("templates/help.tpl", $page_vars);