---------------------------------------------------------------------------------------------------
Form Tools - generic form processing, storage and access script
Copyright (c) 2012 Benjamin Keen
http://www.formtools.org

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License included in this zipfile for more details.
---------------------------------------------------------------------------------------------------


Readme.txt
----------

This software is distributed under the GNU General Public License. Please see the attached
license.txt file included in this zipfile.

Legal stuff aside, for installation instructions, please visit this URL:
http://docs.formtools.org/installation/
