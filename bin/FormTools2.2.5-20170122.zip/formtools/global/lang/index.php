<?php

// redirect to client list page
session_write_close();
header("Location: ../../logout.php");

?>