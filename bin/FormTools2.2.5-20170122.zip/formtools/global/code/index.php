<?php

ft_logout_user();

?>